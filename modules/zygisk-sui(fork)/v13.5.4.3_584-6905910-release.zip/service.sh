#!/system/bin/sh

MODDIR=${0%/*}

. "$MODDIR/logging.sh"

mkdir -p "$SUI_LOG_DIR" 2>/dev/null

print_log() {
    log -p i -t Sui "[Daemon] $1"
}

get_sui_root_pids() {
    if command -v pidof >/dev/null 2>&1; then
        pidof sui 2>/dev/null
        return
    fi

    ps -A 2>/dev/null | awk '$NF == "sui" { print $2 }'
}

get_sui_shell_pids() {
    if command -v pidof >/dev/null 2>&1; then
        pidof sui_shell 2>/dev/null
        return
    fi

    ps -A 2>/dev/null | awk '$NF == "sui_shell" { print $2 }'
}

count_pids() {
    pids="$1"
    if [ -z "$pids" ]; then
        echo 0
        return
    fi
    set -- $pids
    echo $#
}

collect_sui_state() {
    sui_root_pids="$(get_sui_root_pids)"
    sui_shell_pids="$(get_sui_shell_pids)"
    sui_root_count="$(count_pids "$sui_root_pids")"
    sui_shell_count="$(count_pids "$sui_shell_pids")"
}

is_sui_pair_healthy() {
    collect_sui_state
    [ "$sui_root_count" -eq 1 ] && [ "$sui_shell_count" -eq 1 ]
}

kill_pid_list() {
    pids="$1"
    signal="$2"

    if [ -z "$pids" ]; then
        return 0
    fi

    kill "$signal" $pids 2>/dev/null
}

stop_sui_pair() {
    collect_sui_state

    kill_pid_list "$sui_shell_pids" -TERM
    kill_pid_list "$sui_root_pids" -TERM
    sleep 1

    collect_sui_state
    kill_pid_list "$sui_shell_pids" -KILL
    kill_pid_list "$sui_root_pids" -KILL
    sleep 1
}

read_metadata() {
    [ -f "$1" ] && cat "$1" 2>/dev/null
}

get_process_pids() {
    if command -v pidof >/dev/null 2>&1; then
        pidof "$1" 2>/dev/null
        return
    fi

    ps -A 2>/dev/null | awk -v process="$1" '$NF == process { print $2 }'
}

metadata_field() {
    printf '%s\n' "$1" | awk -v line="$2" 'NR == line { print; exit }'
}

get_pid_uid() {
    awk '/^Uid:/ { print $2; exit }' "/proc/$1/status" 2>/dev/null
}

get_pid_start_time() {
    awk '{ print $22 }' "/proc/$1/stat" 2>/dev/null
}

get_pid_process_name() {
    tr '\000' '\n' < "/proc/$1/cmdline" 2>/dev/null | awk 'NR == 1 { print; exit }'
}

kill_process_identity_once() {
    expected_uid="$1"
    process_name="$2"
    killed=0

    for pid in $(get_process_pids "$process_name"); do
        start_time="$(get_pid_start_time "$pid")"
        if [ -z "$start_time" ]; then
            continue
        fi
        if [ "$(get_pid_uid "$pid")" != "$expected_uid" ]; then
            continue
        fi
        if [ "$(get_pid_process_name "$pid")" != "$process_name" ]; then
            continue
        fi
        if [ "$(get_pid_start_time "$pid")" != "$start_time" ]; then
            continue
        fi
        print_log "Package metadata changed, restarting $process_name (uid: $expected_uid, pid: $pid)"
        if kill -9 "$pid" 2>/dev/null; then
            killed=1
        fi
    done

    [ "$killed" -eq 1 ]
}

restart_metadata_process() {
    metadata="$1"
    wait_attempts="$2"
    expected_uid="$(metadata_field "$metadata" 2)"
    process_name="$(metadata_field "$metadata" 3)"

    case "$expected_uid" in
        ""|*[!0-9]*) return ;;
    esac
    case "$process_name" in
        ""|init|system_server|zygote*) return ;;
    esac

    attempt=0
    while true; do
        if kill_process_identity_once "$expected_uid" "$process_name"; then
            return
        fi
        if [ "$attempt" -ge "$wait_attempts" ]; then
            return
        fi
        attempt=$((attempt + 1))
        sleep 1
    done
}

restart_changed_metadata_processes() {
    old_metadata="$1"
    new_metadata="$2"
    old_identity="$(metadata_field "$old_metadata" 2):$(metadata_field "$old_metadata" 3)"
    new_identity="$(metadata_field "$new_metadata" 2):$(metadata_field "$new_metadata" 3)"

    if [ "$old_identity" != "$new_identity" ]; then
        restart_metadata_process "$old_metadata" 0
    fi
    restart_metadata_process "$new_metadata" 10
}

refresh_metadata() {
    metadata_changed=0
    old_system_ui="$(read_metadata "$MODDIR/system_ui")"
    old_settings="$(read_metadata "$MODDIR/settings")"

    print_log "Refreshing SystemUI and Settings package metadata..."
    refresh_status=0
    run_sui_installer_command /system/bin/app_process -Djava.class.path="$MODDIR"/sui.dex /system/bin \
        --nice-name=sui_installer rikka.sui.installer.Installer "$MODDIR" \
        </dev/null >/dev/null 2>&1 || refresh_status=$?

    new_system_ui="$(read_metadata "$MODDIR/system_ui")"
    new_settings="$(read_metadata "$MODDIR/settings")"
    if [ "$old_system_ui" != "$new_system_ui" ]; then
        metadata_changed=1
        restart_changed_metadata_processes "$old_system_ui" "$new_system_ui"
    fi
    if [ "$old_settings" != "$new_settings" ]; then
        metadata_changed=1
        restart_changed_metadata_processes "$old_settings" "$new_settings"
    fi

    if [ "$refresh_status" -ne 0 ]; then
        print_log "Package metadata refresh failed"
        return 1
    fi
    if [ ! -s "$MODDIR/system_ui" ] || [ ! -s "$MODDIR/settings" ]; then
        print_log "Package metadata is unavailable"
        return 1
    fi
    return 0
}

start_sui() {
    chmod 700 "$MODDIR/bin/sui" 2>/dev/null
    start_sui_logged_daemon 0
}

acquire_private_watchdog_lock() {
    FALLBACK_LOCK_DIR="$SUI_LOG_DIR/.watchdog.lock"
    if ! mkdir "$FALLBACK_LOCK_DIR" 2>/dev/null; then
        read -r owner owner_start < "$FALLBACK_LOCK_DIR/owner" 2>/dev/null || :
        if sui_process_alive "$owner" "$owner_start"; then
            return 1
        fi
        sleep 2
        read -r owner owner_start < "$FALLBACK_LOCK_DIR/owner" 2>/dev/null || :
        if sui_process_alive "$owner" "$owner_start"; then
            return 1
        fi
        rm -f "$FALLBACK_LOCK_DIR/owner"
        rmdir "$FALLBACK_LOCK_DIR" 2>/dev/null || return 1
        mkdir "$FALLBACK_LOCK_DIR" 2>/dev/null || return 1
    fi

    read -r lock_owner _ < /proc/self/stat
    lock_start="$(awk '{print $22}' "/proc/$lock_owner/stat" 2>/dev/null)"
    printf '%s %s\n' "$lock_owner" "$lock_start" > "$FALLBACK_LOCK_DIR/owner"
    trap 'rm -f "$FALLBACK_LOCK_DIR/owner"; rmdir "$FALLBACK_LOCK_DIR" 2>/dev/null' EXIT
}

LOCK_FILE="$SUI_LOG_DIR/watchdog.lock.v2"
if ! exec 9>> "$LOCK_FILE"; then
    exit 1
fi
if command -v flock >/dev/null 2>&1; then
    if ! flock -n 9 2>/dev/null; then
        exit 0
    fi
elif [ -x /system/bin/toybox ]; then
    if /system/bin/toybox flock --help >/dev/null 2>&1; then
        if ! /system/bin/toybox flock -n 9 2>/dev/null; then
            exit 0
        fi
    else
        acquire_private_watchdog_lock || exit 0
    fi
else
    acquire_private_watchdog_lock || exit 0
fi
trap 'exit 0' INT TERM

start_sui_log_collector

metadata_ready=0
metadata_changed=0
if refresh_metadata; then
    metadata_ready=1
    if [ "$metadata_changed" -eq 1 ] && is_sui_pair_healthy; then
        print_log "Package metadata changed, restarting Sui process pair..."
        stop_sui_pair
        start_sui
        sleep 2
    fi
fi

backoff=1
backoff_max=60
interval=5

while true; do
    start_sui_log_collector

    if is_sui_pair_healthy; then
        if [ "$metadata_ready" -eq 0 ] && refresh_metadata; then
            metadata_ready=1
        fi
        backoff=1
        sleep "$interval"
        continue
    fi

    case "$sui_root_count:$sui_shell_count" in
        0:0) print_log "Sui root and shell servers are not running, restarting..." ;;
        0:*) print_log "Sui root server is not running, restarting pair..." ;;
        *:0) print_log "Sui shell server is not running, restarting pair..." ;;
        *) print_log "Sui process pair is inconsistent (root=$sui_root_pids shell=$sui_shell_pids), restarting..." ;;
    esac
    stop_sui_pair
    if [ "$metadata_ready" -eq 1 ] || refresh_metadata; then
        metadata_ready=1
        start_sui
    else
        print_log "Retrying metadata refresh later"
    fi
    sleep 2

    if is_sui_pair_healthy; then
        print_log "Sui process pair is running (root=$sui_root_pids shell=$sui_shell_pids)"
        backoff=1
        sleep "$interval"
        continue
    fi

    print_log "Sui daemon still not running, retry in ${backoff}s"
    sleep "$backoff"
    if [ "$backoff" -lt "$backoff_max" ]; then
        backoff=$((backoff * 2))
        if [ "$backoff" -gt "$backoff_max" ]; then
            backoff="$backoff_max"
        fi
    fi
done
